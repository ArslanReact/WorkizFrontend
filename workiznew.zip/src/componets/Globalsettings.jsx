class MyGlobleSetting {
    constructor() {
      this.url = 'https://tecmyer.com.au/projects/reactworkiz/backend/public/';
    }
  }
export default (new MyGlobleSetting);