const JobsBoxLoopArray = [
    {
        key: "0",
        title: "Submited",
        countnumber: "12",
    },
    {
        key: "1",
        title: "Pending",
        countnumber: "6",
    },
    {
        key: "2",
        title: "In Progress",
        countnumber: "04",
    },
    {
        key: "3",
        title: "Done pend approval",
        countnumber: "15",
    },
    {
        key: "4",
        title: "In Progress",
        countnumber: "15",
    },
]
export default JobsBoxLoopArray;
