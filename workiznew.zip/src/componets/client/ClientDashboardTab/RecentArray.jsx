const RecentArray = [
    {
        key: "0",
        small: "Erik Spoelstra",
        title: "Added payment 500...",
        hashnumber: "#1",
        smallnumber: "a few soconds ago",

    },
    {
        key: "1",
        small: "Erik Spoelstra",
        title: "Update parts cost $0",
        hashnumber: "#2",
        smallnumber: "a few soconds ago",
    },
    {
        key: "2",
        small: "Erik Spoelstra",
        title: "Added item Soap (52...",
        hashnumber: "#3",
        smallnumber: "a few soconds ago",
    },
    {
        key: "3",
        small: "Erik Spoelstra",
        title: "Loged in from 147...",
        hashnumber: "#4",
        smallnumber: "a few soconds ago",
    },
]

export default RecentArray;