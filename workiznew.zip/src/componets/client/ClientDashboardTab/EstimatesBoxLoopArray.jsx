const EstimatesBoxLoopArray = [
    {
        key: "0",
        text1: "Unsent",
        smalltext: "Worth $ 0.00",
        countnumber: "1",
    },
    {
        key: "1",
        text1: "Pending",
        smalltext: "Worth $ 4587.00",
        countnumber: "2",
    },
    {
        key: "2",
        text1: "Approved",
        smalltext: "Worth $ 0.00",
        countnumber: "0",
    },
    {
        key: "3",
        text1: "Denied",
        smalltext: "Worth $ 0.00",
        countnumber: "5",
    },
]
export default EstimatesBoxLoopArray;