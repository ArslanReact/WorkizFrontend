
const InvoicesBoxLoopArray = [
    {
        key: "0",
        viewall: "View All",
        title: "WordPress Development",
        clientname: "Otho Bogisich IV",
        projectname: "Xcvxvxcv#005",
    },
]
export default InvoicesBoxLoopArray;