import React from 'react';

const ClientCreditNote = (props) => {
    return (
        <>
            <tr>
                <td colSpan="8" className="text-center">No data available in table</td>
            </tr>
        </>
    )
}

export default ClientCreditNote;
