import React from 'react';

const ClientEvents = () => {
    return (
        <>
            https://www.npmjs.com/package/event-calendar
        </>
    )
}

export default ClientEvents;
