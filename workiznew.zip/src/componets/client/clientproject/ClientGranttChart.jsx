import React from 'react';

const ClientGranttChart = () => {
    return (
        <>
            Grantt_Chart
        </>
    )
}

export default ClientGranttChart;
