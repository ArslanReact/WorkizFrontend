import React from 'react';

const UpdateTitle = (props) => {
    return (
        <>
            <p className="ml-2 fontweightbold blusecolortext">{props.count_number}</p>
        </>
    )
}

export default UpdateTitle;
