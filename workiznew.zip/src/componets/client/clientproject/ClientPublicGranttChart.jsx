import React from 'react';

const ClientPublicGranttChart = () => {
    return (
        <>
            Public_Grantt_Chart
        </>
    )
}

export default ClientPublicGranttChart;
