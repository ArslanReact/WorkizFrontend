import React from 'react';

const EmployeeEvents = () => {
    return (
        <>
            https://www.npmjs.com/package/event-calendar
        </>
    )
}

export default EmployeeEvents;
