import React from 'react';

const Error = () => {
    return (
        <>
            <h1>Opps! Page Not Found!</h1>
        </>
    )
}

export default Error;
