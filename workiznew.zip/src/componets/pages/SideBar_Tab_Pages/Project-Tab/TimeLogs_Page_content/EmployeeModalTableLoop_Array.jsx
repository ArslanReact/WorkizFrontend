const EmployeeModalTableLoop_Array = [
    {
        key: "0",
        countnumber: "1",
        employename: "Employee",
        taskname: "fgfg",
        smallname: "Tenetur vel totam",
        memoname: "gfgfg",
        badgetext: "Stop",
        badgebgcolor: "redcolortext badgepinkbg",
    },
]
export default EmployeeModalTableLoop_Array;