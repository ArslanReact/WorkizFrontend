// 
import avatarimg from "../../../../../assets/images/avatar_01.svg";
import editimg from "../../../../../assets/images/edit_2_iconimg.svg";
import deleteimg from "../../../../../assets/images/deleteiconimg.svg";

const EmployeeLogTable_Array = [
    {
        key: "0",
        avatarimg: avatarimg,
        title: "Mrs. Adele Hayes",
        smalltitle: "Senior",
        hourscount: "0 Hours Logged",
        dolortext: "$0 Earnings",

        task_name: "Architecto.",
        time_name: "06-04-2021 08:15 AM",
        hours_name: "8 hrs",
        eearnings_name: "$0",
        editimg: editimg,
        deleteimg: deleteimg,
    },
    {
        key: "1",
        avatarimg: avatarimg,
        title: "Mrs. Adele Hayes",
        smalltitle: "Senior",
        hourscount: "0 Hours Logged",
        dolortext: "$0 Earnings",

        task_name: "Architecto.",
        time_name: "06-04-2021 08:15 AM",
        hours_name: "6 hrs",
        eearnings_name: "$0",
        editimg: editimg,
        deleteimg: deleteimg,
    },
]
export default EmployeeLogTable_Array;