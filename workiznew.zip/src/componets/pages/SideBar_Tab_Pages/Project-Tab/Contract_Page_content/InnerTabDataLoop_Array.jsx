
// 
import thumbnail from "../../../../../assets/images/thumnail_1.jpg";

const InnerTabDataLoop_Array = [
    {
        key: "0",
        time: "51 seconds ago",
        thumbnailimg: thumbnail,
        title: "Skype_Picture.jpg",
    },
]
export default InnerTabDataLoop_Array;