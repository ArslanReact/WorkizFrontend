
// 
import editiconimg from "../../../../../assets/images/editimgicon.svg";
import crossimg from "../../../../../assets/images/crossiconimg.svg";
import avatar from "../../../../../assets/images/avatar_01.svg";

const DiscussionListLoop_Array = [
    {
        key: "0",
        titlename: "Admin",
        time: "1 second before",
        crossimg: crossimg,
        editiconimg: editiconimg,
        avatarimg: avatar,
    },
    {
        key: "1",
        titlename: "Admin",
        time: "5 second before",
        crossimg: crossimg,
        editiconimg: editiconimg,
        avatarimg: avatar,
    },
    {
        key: "2",
        titlename: "Admin",
        time: "10 second before",
        crossimg: crossimg,
        editiconimg: editiconimg,
        avatarimg: avatar,
    },
]
export default DiscussionListLoop_Array;