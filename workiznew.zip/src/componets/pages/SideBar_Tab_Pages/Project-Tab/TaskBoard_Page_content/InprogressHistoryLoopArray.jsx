import avatarimg from "../../../../../assets/images/avatar_01.svg";
const InprogressHistoryLoopArray = [
    {
        key: "0",
        title: "Task details are updated by Admin",
        time: "17-04-2021 01:07 PM",
        avatar: avatarimg,
        colorupdate: "greencolorbg text-white",
        completeincomplete: "Completed",
    },
    {
        key: "0",
        title: "Task details are updated by Admin",
        time: "17-04-2021 01:07 PM",
        avatar: avatarimg,
        colorupdate: "redcolorbg text-white",
        completeincomplete: "Incompleted",
    },
]
export default InprogressHistoryLoopArray;