import React from 'react';

const Public_Grantt_Chart = () => {
    return (
        <>
            Public_Grantt_Chart
        </>
    )
}

export default Public_Grantt_Chart;
