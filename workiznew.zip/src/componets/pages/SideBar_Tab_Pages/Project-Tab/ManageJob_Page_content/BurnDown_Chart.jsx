import React from 'react';

const BurnDown_Chart = () => {
    return (
        <>
            BurnDown Chart
        </>
    )
}

export default BurnDown_Chart;
