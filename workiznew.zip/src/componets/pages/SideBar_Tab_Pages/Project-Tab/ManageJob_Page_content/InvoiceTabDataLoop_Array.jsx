const InvoiceTabDataLoop_Array = [
    {
        key: "0",
        invoicename: "INV#040",
        amount: "$0.00",
        badgetext: "Unpaid",
        badgebgcolor: "redcolortext badgeredbg",
        time: "15-03-2021 ",
    },
    {
        key: "1",
        invoicename: "INV#040",
        amount: "$0.00",
        badgetext: "Unpaid",
        badgebgcolor: "redcolortext badgeredbg",
        time: "15-03-2021 ",
    },
]
export default InvoiceTabDataLoop_Array;