
// 
import avataricon from "../../../../../assets/images/avatar_04.svg";
import crossicon from "../../../../../assets/images/crossiconimg.svg";

const DiscussionDataLoop_Array = [
    {
        key: "0",
        avatarimg: avataricon,
        title: "Web Design",
        admintext: "Admin",
        description: "posted on 27-05-2021 04:46 PM",
        number: "1",
        name: "Design",
        badgebgcolor: "blusecolorbg",
        crossicon: crossicon,
    },
    {
        key: "1",
        avatarimg: avataricon,
        title: "Web Development",
        admintext: "Admin",
        description: "posted on 27-05-2021 04:46 PM",
        number: "1",
        name: "Design",
        badgebgcolor: "greencolorbg",
        crossicon: crossicon,
    },
]
export default DiscussionDataLoop_Array;