import React from 'react';

const Plus_Page = () => {
    return (
        <>
            Add_Job_Member
        </>
    )
}

export default Plus_Page;
