import React from 'react';

const TasksBoardPanelLoop = () => {
    return (
        <>
            <div className="card card_dashboard card-body">
                TasksBoard
            </div>
        </>
    )
}

export default TasksBoardPanelLoop;
