import React from 'react';

const InvoicesPanelLoop = () => {
    return (
        <>
            <div className="card_dashboard card card-body">
                Invoices
            </div>
        </>
    )
}

export default InvoicesPanelLoop;
