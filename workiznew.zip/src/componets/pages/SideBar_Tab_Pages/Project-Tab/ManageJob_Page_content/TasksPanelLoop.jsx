import React from 'react';

const TasksPanelLoop = () => {
    return (
        <>
            <div className="card card_dashboard card-body">
                Tasks
            </div>
        </>
    )
}

export default TasksPanelLoop;
