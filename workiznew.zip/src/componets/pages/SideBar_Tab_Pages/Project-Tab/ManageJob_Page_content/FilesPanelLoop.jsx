import React from 'react';

const FilesPanelLoop = () => {
    return (
        <>
            <div className="card_dashboard card card-body">
                Files
            </div>
        </>
    )
}

export default FilesPanelLoop;
