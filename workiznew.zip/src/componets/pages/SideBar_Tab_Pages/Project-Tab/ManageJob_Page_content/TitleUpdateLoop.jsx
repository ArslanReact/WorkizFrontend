import React from 'react';

const TitleUpdateLoop = (props) => {
    return (
        <>
            <h5 className="main_title ml-3"><span>{props.hashtitle}</span> {props.looptitle}</h5>
        </>
    )
}

export default TitleUpdateLoop;
