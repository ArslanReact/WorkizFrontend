
// 
import avatarimg from "../../../../../assets/images/avatar_01.svg";
import editimgicon from "../../../../../assets/images/editimgicon.svg";
import deleteimgicon from "../../../../../assets/images/deleteimgicon.svg";

const MilestonesPanelLoop_Array = [
    {
        key: "0",
        countnumber: "1",
        avatarname: "Steve Gleason",
        smalltitle: "Team Lead",
        price: "$500",
        badgetext: "Complete",
        badgebgcolor: "",
        avatarimg: avatarimg,
        editimgicon: editimgicon,
        deleteimgicon: deleteimgicon,
    },
    {
        key: "1",
        countnumber: "2",
        avatarname: "Steve Gleason",
        smalltitle: "Team Lead",
        price: "$500",
        badgetext: "Complete",
        badgebgcolor: "",
        avatarimg: avatarimg,
        editimgicon: editimgicon,
        deleteimgicon: deleteimgicon,
    },
]
export default MilestonesPanelLoop_Array;