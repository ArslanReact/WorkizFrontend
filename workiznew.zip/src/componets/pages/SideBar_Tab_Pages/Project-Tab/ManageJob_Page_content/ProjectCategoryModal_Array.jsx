

const ProjectCategoryModal_Array = [
    {
        key: "0",
        countnumber: "1",
        name: "DS",
        remove: "Remove",
    },
    {
        key: "1",
        countnumber: "2",
        name: "	Laravel",
        remove: "Remove",
    },
]
export default ProjectCategoryModal_Array;