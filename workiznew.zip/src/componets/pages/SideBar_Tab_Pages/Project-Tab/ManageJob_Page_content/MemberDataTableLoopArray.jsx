
// 
import avatarimg from "../../../../../assets/images/avatar_04.svg";
import crossicon from "../../../../../assets/images/crossiconimg.svg";

const MemberDataTableLoopArray = [
    {
        key: "0",
        avatarimg: avatarimg,
        title: "Rizal Ramadhan",
        paragraph: "rizalramadhan@gmail.com",
        crossicon: crossicon,
    },
]
export default MemberDataTableLoopArray;