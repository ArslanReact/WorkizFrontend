import React from 'react';

const Grantt_Chart = () => {
    return (
        <>
            Grantt_Chart
        </>
    )
}

export default Grantt_Chart;
