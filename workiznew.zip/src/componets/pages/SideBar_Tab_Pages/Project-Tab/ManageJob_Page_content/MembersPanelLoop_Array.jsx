
// 
import avatarimg from "../../../../../assets/images/avatar_01.svg";
import editimgicon from "../../../../../assets/images/editimgicon.svg";
import deleteimgicon from "../../../../../assets/images/deleteimgicon.svg";

const MembersPanelLoop_Array = [
    {
        key: "0",
        avatarname: "Steve Gleason",
        smalltitle: "Team Lead",
        rate: "0",
        avatarimg: avatarimg,
        editimgicon: editimgicon,
        deleteimgicon: deleteimgicon,
    },
    {
        key: "1",
        avatarname: "Steve Gleason",
        smalltitle: "Team Lead",
        rate: "0",
        avatarimg: avatarimg,
        editimgicon: editimgicon,
        deleteimgicon: deleteimgicon,
    },
]
export default MembersPanelLoop_Array;