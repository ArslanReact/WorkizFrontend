const ActivityTimelineLoop_Array = [
    {
        key: "0",
        title: "New task added to the project.",
        smalltext1: "You have an upcoming Task",
        smalltext2: "26 minutes ago",
    },
    {
        key: "1",
        title: "Follow-up with ISV on proposal-2",
        smalltext1: "You have an upcoming Task",
        smalltext2: "26 minutes ago",
    },
    {
        key: "2",
        title: "Follow-up with ISV on proposal-2",
        smalltext1: "You have an upcoming Task",
        smalltext2: "26 minutes ago",
    },
    {
        key: "3",
        title: "New task added to the project.",
        smalltext1: "You have an upcoming Task",
        smalltext2: "26 minutes ago",
    },
]
export default ActivityTimelineLoop_Array;