import React from 'react';

const Rating = () => {
    return (
        <>
            <div className="container-fluid mb-4">
                <h4 className="main_title px-0">Rating</h4>
            </div>
            {/*  */}
            <div className="container-fluid">
                <div className="card_dashboard card card-body">
                    <p>No rating found</p>
                </div>
            </div>
        </>
    )
}

export default Rating;
