
// 
import avataricon from "../../../../../assets/images/avatar_04.svg";
import iconimg from "../../../../../assets/images/dotoption.svg";
import editiconimg from "../../../../../assets/images/editiconimg.svg";
import deleteiconimg from "../../../../../assets/images/deleteiconimg.svg";

const TimeLogDataLoop_Array = [
    {
        key: "0",
        countnumber: "1",
        avatarimg: avataricon,
        titlename: "Mrs. Adele Hayes",
        taskname: "	Autem praesentium. Task 3",
        starttime: "28-02-2021 08:15 AM",
        endtime: "28-02-2021 08:15 AM",
        hourtime: "8 hrs",
        memoname: "working on database",
        adminname: "Admin",
        editiconimg: editiconimg,
        iconimg: iconimg,
        deleteiconimg: deleteiconimg,
    },
    {
        key: "1",
        countnumber: "2",
        avatarimg: avataricon,
        titlename: "Mrs. Adele Hayes",
        taskname: "	Autem praesentium. Task 3",
        starttime: "28-02-2021 08:15 AM",
        endtime: "28-02-2021 08:15 AM",
        hourtime: "8 hrs",
        memoname: "working on database",
        adminname: "Admin",
        editiconimg: editiconimg,
        iconimg: iconimg,
        deleteiconimg: deleteiconimg,
    },
]
export default TimeLogDataLoop_Array;