const TitleUpdateLoopArray = [
    {
        key: "0",
        looptitle: "Dashboard Design",
        hashtitle: "#3",
    },
]
export default TitleUpdateLoopArray;