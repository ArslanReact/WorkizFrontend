
// 
import avatarimg from "../../../../../assets/images/avatar_04.svg";
import avatarimg1 from "../../../../../assets/images/avatar_05.svg";

const MemberDataLoopArray = [
    {
        key: "0",
        avatarimg: avatarimg,
        title: "Rizal Ramadhan",
        paragraph: "rizalramadhan@gmail.com",
    },
    {
        key: "1",
        avatarimg: avatarimg1,
        title: "Asish Sunny",
        paragraph: "asishsunny@gmail.com",
    },
    {
        key: "1",
        avatarimg: avatarimg,
        title: "Omnicreativora",
        paragraph: "omnicreattivora@gmail.com",
    },
]
export default MemberDataLoopArray;