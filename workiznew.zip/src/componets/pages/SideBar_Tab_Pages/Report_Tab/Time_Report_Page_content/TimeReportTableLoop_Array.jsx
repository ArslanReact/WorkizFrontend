const TimeReportTableLoop_Array = [
    {
        key: "0",
        countnumber: "1",
        projectname: "Dicta nihil.",
        invoicename: "Uriel Bailey",
        amount: "05-04-2021 07:15 AM",
        paidon: "05-04-2021 04:15 PM",
        badgetext: "9 hrs",
        remark: "$0 (USD)",
    },
]
export default TimeReportTableLoop_Array;