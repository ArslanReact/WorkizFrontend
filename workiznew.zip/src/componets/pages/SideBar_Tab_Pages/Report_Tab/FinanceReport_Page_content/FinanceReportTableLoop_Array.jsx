const FinanceReportTableLoop_Array = [
    {
        key: "0",
        countnumber: "1",
        projectname: "Et voluptatem qui.",
        invoicename: "INV#001",
        amount: "$6585 (USD)",
        paidon: "03-04-2021 12:00 AM",
        badgebgcolor: "badgegreenbg greencolortext",
        badgetext: "Complete",
        remark: "Sd",
    },
]
export default FinanceReportTableLoop_Array;