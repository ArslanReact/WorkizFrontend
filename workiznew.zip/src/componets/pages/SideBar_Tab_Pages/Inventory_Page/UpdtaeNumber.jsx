import React from 'react';

const UpdtaeNumber = (props) => {
    return (
        <>
            <p className="ml-2 mr-1 fontsize16 fontweightbold blusecolortext">{props.countnumber}</p>
        </>
    )
}

export default UpdtaeNumber;
