

const DataTableLoopModal_3_Array = [
    {
        key: "0",
        countnumber: "1",
        name: "DS",
        ratename: "10%",
        remove: "Remove",
    },
    {
        key: "1",
        countnumber: "2",
        name: "	Laravel",
        ratename: "20%",
        remove: "Remove",
    },
]
export default DataTableLoopModal_3_Array;