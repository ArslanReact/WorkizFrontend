const MapDataLoop_Array = [
    {
        key: "0",
        name: "Make Software",
        badgetext: "Deadline: 2021-03-25",
    },
    {
        key: "1",
        name: "Make Software",
        badgetext: "Deadline: 2021-03-25",
    },
    {
        key: "2",
        name: "Make Software",
        badgetext: "Deadline: 2021-03-25",
    },
]
export default MapDataLoop_Array;