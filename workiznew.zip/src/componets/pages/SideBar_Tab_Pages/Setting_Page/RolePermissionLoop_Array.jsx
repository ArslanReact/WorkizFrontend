
// 

const RolePermissionLoop_Array = [
    {
        key: "0",
        managebtn: "Manage Role",
    },
]
export default RolePermissionLoop_Array;