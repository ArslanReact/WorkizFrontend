

const DataTableLoopModal2Array = [
    {
        key: "0",
        countnumber: "1",
        name: "Sales",
        remove: "Remove",
    },
    {
        key: "1",
        countnumber: "2",
        name: "	Code",
        remove: "Remove",
    },
    {
        key: "1",
        countnumber: "3",
        name: "	Management",
        remove: "Remove",
    },
]
export default DataTableLoopModal2Array;