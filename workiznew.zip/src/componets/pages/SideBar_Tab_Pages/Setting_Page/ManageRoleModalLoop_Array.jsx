const ManageRoleModalLoop_Array = [
    {
        key: "0",
        countnumber: "1",
        name: "Admin",
        default_text: "Default role can not be deleted.",
    },
    {
        key: "0",
        countnumber: "2",
        name: "Employee",
        default_text: "Default role can not be deleted.",
    },
    {
        key: "0",
        countnumber: "3",
        name: "Client",
        default_text: "Default role can not be deleted.",
    },
]
export default ManageRoleModalLoop_Array;