

const DataTableLoopModal1Array = [
    {
        key: "0",
        countnumber: "1",
        name: "Employee",
        role: "Client",
        remove: "Remove",
    },
]
export default DataTableLoopModal1Array;