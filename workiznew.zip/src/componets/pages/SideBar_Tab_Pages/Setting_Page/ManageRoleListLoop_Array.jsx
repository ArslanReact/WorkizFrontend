const ManageRoleListLoop_Array = [
    {
        key: "0",
        name: "Client",
        badgetext: "0 Member(s)",
        badgebg: "badgepinkbg redcolortext",
        perbadgetext: "Permissions",
        perbadgebg: "blusecolorbg text-white",
    },
]
export default ManageRoleListLoop_Array;