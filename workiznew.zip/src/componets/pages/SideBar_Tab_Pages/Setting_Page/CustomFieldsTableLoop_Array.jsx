// 
import editiconimg from "../../../../assets/images/editimgicon.svg";
import crossimg from "../../../../assets/images/crossiconimg.svg";

const CustomFieldsTableLoop_Array = [
    {
        key: "0",
        projectname: "Project",
        label: "text",
        name: "text",
        type: "type",
        value: "--",
        requiredtext: "Yes",
        badgebgcolor: "badgeredbg redcolortext",
        crossimg: crossimg,
        editiconimg: editiconimg,
    },
]
export default CustomFieldsTableLoop_Array;