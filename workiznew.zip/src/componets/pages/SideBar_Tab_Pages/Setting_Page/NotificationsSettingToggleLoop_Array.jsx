const NotificationsSettingToggleLoop_Array = [
    {
        key: "0",
        labeltext: "User Registration/Added by Admin",
    },
    {
        key: "1",
        labeltext: "Employee Assign to Job",
    },
]
export default NotificationsSettingToggleLoop_Array;