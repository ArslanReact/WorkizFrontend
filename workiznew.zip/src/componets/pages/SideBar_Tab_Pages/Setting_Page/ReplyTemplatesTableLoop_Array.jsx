// 
import editiconimg from "../../../../assets/images/editimgicon.svg";
import crossimg from "../../../../assets/images/crossiconimg.svg";

const ReplyTemplatesTableLoop_Array = [
    {
        key: "0",
        countnumber: "1",
        name: "Name",
        crossimg: crossimg,
        editiconimg: editiconimg,
    },
]
export default ReplyTemplatesTableLoop_Array;