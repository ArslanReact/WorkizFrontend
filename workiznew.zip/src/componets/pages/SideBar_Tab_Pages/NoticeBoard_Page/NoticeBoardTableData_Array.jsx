// 
import iconimg from "../../../../assets/images/dotoption.svg";
import editiconimg from "../../../../assets/images/editiconimg.svg";
import viewiconimg from "../../../../assets/images/viewiconimg.svg";
import deleteiconimg from "../../../../assets/images/deleteiconimg.svg";

const NoticeBoardTableData_Array = [
    {
        key: "0",
        countnumber: "1",
        name: "However, I've got to see what the flame of a sea of green leaves.",
        date: "09-04-2021",
        to: "Employee",
        editiconimg: editiconimg,
        iconimg: iconimg,
        viewiconimg: viewiconimg,
        deleteiconimg: deleteiconimg,
    },
    {
        key: "1",
        countnumber: "2",
        name: "However, I've got to see what the flame of a sea of green leaves.",
        date: "05-04-2021",
        to: "Employee",
        editiconimg: editiconimg,
        iconimg: iconimg,
        viewiconimg: viewiconimg,
        deleteiconimg: deleteiconimg,
    },
    {
        key: "2",
        countnumber: "3",
        name: "However, I've got to see what the flame of a sea of green leaves.",
        date: "02-04-2021",
        to: "Employee",
        editiconimg: editiconimg,
        iconimg: iconimg,
        viewiconimg: viewiconimg,
        deleteiconimg: deleteiconimg,
    },
]
export default NoticeBoardTableData_Array;