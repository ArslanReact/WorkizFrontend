const LeadFormDataTable_Array = [
    {
        key: "0",
        countnumber: "1",
        fieldname: "Name",
        notyes: "d-none",
    },
    {
        key: "1",
        countnumber: "2",
        fieldname: "Email",
        notyes: "d-none",
    },
    {
        key: "2",
        countnumber: "3",
        fieldname: "Company Name",
    },
    {
        key: "3",
        countnumber: "4",
        fieldname: "Website",
    },
]
export default LeadFormDataTable_Array;