

const DataTableLoopModalOneArray = [
    {
        key: "0",
        countnumber: "1",
        name: "DS",
        remove: "Remove",
    },
    {
        key: "1",
        countnumber: "2",
        name: "	Laravel",
        remove: "Remove",
    },
]
export default DataTableLoopModalOneArray;