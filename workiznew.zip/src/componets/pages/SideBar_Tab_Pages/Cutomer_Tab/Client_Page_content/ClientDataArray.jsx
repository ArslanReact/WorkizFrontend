import iconimg from "../../../../../assets/images/dotoption.svg";
import editiconimg from "../../../../../assets/images/editiconimg.svg";
import viewiconimg from "../../../../../assets/images/viewiconimg.svg";
import deleteiconimg from "../../../../../assets/images/deleteiconimg.svg";
const ClientDataArray = [
    {
        key: "0",
        countnumber: "1133",
        name: "Mr. Ramiro Purdy III",
        company: "Langworth Inc",
        email: "herzog.wilfrid@yahoo.com",
        phone: "(213) 934-0342",
        date: "11-03-2021",
        editiconimg: editiconimg,
        iconimg: iconimg,
        viewiconimg: viewiconimg,
        deleteiconimg: deleteiconimg,
    },
    {
        key: "1",
        countnumber: "1132",
        name: "Kasey Rohan V",
        company: "Green LLC",
        email: "damon.sanford@yahoo.com",
        phone: "(213) 784-9344",
        date: "12-07-2021",
        editiconimg: editiconimg,
        iconimg: iconimg,
        viewiconimg: viewiconimg,
        deleteiconimg: deleteiconimg,
    },
]
export default ClientDataArray;