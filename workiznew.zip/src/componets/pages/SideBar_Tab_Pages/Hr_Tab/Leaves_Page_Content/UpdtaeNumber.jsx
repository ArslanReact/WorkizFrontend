import React from 'react';

const UpdtaeNumber = (props) => {
    return (
        <>
            <p className="mx-1 fontsize16 fontweightbold blusecolortext">{props.count_number}</p>
        </>
    )
}

export default UpdtaeNumber;
