import checkicon from "../../../../../assets/images/checkgreenicon.svg";
const LeaveTypeModalLoop_Array = [
    {
        key: "0",
        badgetext: "Casual",
        badgebgcolor: "badgegreenbg greencolortext",
        checkicon: checkicon,
    },
    {
        key: "1",
        badgetext: "Sick",
        badgebgcolor: "badgepinkbg redcolortext",
        checkicon: checkicon,
    },
    {
        key: "2",
        badgetext: "Earned",
        badgebgcolor: "badgelightbluebg lightbluecolortext",
        checkicon: checkicon,
    },
]
export default LeaveTypeModalLoop_Array;