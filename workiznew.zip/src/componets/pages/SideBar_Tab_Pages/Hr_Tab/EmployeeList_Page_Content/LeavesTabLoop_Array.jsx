const LeavesTabLoop_Array = [
    {
        key: "0",
        text: "Casual",
        badgetext: "0 / 5",
        badgebgcolor: "badgegreenbg greencolortext",
    },
    {
        key: "1",
        text: "Sick",
        badgetext: "0 / 5",
        badgebgcolor: "badgeredbg redcolortext",
    },
    {
        key: "2",
        text: "Earned",
        badgetext: "0 / 5",
        badgebgcolor: "badgelightbluebg seabluecolortext",
    },
]
export default LeavesTabLoop_Array;