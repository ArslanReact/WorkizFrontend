
const Contact_Tab_Table_Array = [
    {
        key: "0",
        countnumber: "1",
        name: "Wordpress Development",
        task: "Autem praesentium. Task 1",
        email: "28-04-2021",
        badgetext: "Completed",
        badgebgcolor: "badgegreenbg greencolortext",
    },
    {
        key: "1",
        countnumber: "2",
        name: "Ecommerce Shopify ",
        task: "Autem praesentium. Task 2",
        email: "28-04-2021",
        badgetext: "Incompleted",
        badgebgcolor: "badgeredbg redcolortext",
    },
    {
        key: "2",
        countnumber: "3",
        name: "Front End Project",
        task: "Autem praesentium. Task 3",
        email: "28-04-2021",
        badgetext: "Completed",
        badgebgcolor: "badgegreenbg greencolortext",
    },
]
export default Contact_Tab_Table_Array;