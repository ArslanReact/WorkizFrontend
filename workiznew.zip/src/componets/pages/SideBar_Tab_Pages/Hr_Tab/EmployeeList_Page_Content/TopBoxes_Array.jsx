import top_icon_1 from "../../../../../assets/images/top_icon_1.svg";
const TopBoxesArray = [
    {
        key: "0",
        iconimg: top_icon_1,
        altburger: "top_icon_2",
        toptitle: "Total Employees",
        classnth: "nth_1",
        topnumber: "54",
    },
    {
        key: "1",
        iconimg: top_icon_1,
        altburger: "top_icon_2",
        toptitle: "Not working on project",
        classnth: "nth_2",
        topnumber: "8",
    },
]
export default TopBoxesArray;