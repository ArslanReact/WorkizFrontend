const PrecencesTabTopBoxes_Array = [
    {
        key: "0",
        box_bg: "badgegreenbg",
        circle_bg: "greencolorbg",
        count_number: "11",
        title: "Total Employees",
    },
    {
        key: "1",
        box_bg: "badgelightbluebg",
        circle_bg: "lightbluecolorbg",
        count_number: "10",
        title: "Present",
    },
    {
        key: "2",
        box_bg: "badgepinkbg",
        circle_bg: "redcolorbg",
        count_number: "6",
        title: "Days Absent",
    },
]
export default PrecencesTabTopBoxes_Array;