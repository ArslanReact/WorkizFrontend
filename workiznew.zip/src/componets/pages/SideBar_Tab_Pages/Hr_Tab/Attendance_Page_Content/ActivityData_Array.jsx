
// 
import clockimg from "../../../../../assets/images/watchblackicon.svg";
import editimg from "../../../../../assets/images/edit_2_iconimg.svg";
import deleteimg from "../../../../../assets/images/deleteiconimg.svg";

const ActivityData_Array = [
    {
        key: "0",
        clocktext: "Clock",
        timetext: "04:30 PM.",
        clockimg: clockimg,
        editimg: editimg,
        deleteimg: deleteimg,
    },
    {
        key: "1",
        clocktext: "Clock",
        timetext: "04:30 PM.",
        clockimg: clockimg,
        editimg: editimg,
        deleteimg: deleteimg,
    },
    {
        key: "1",
        clocktext: "Clock",
        timetext: "04:30 PM.",
        clockimg: clockimg,
        editimg: editimg,
        deleteimg: deleteimg,
    },
]
export default ActivityData_Array;