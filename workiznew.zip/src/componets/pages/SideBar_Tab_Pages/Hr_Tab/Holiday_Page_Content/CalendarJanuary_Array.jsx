// 
import iconimg from "../../../../../assets/images/dotoption.svg";
import deleteiconimg from "../../../../../assets/images/deleteiconimg.svg";

const CalendarFebuary_Array = [
    {
        key: "0",
        ID_number: "1",
        datetext: "06-03-2021",
        Occasiontext: "Saturday",
        daytext: "Sat",
        iconimg: iconimg,
        deleteiconimg: deleteiconimg,
    },
    {
        key: "1",
        ID_number: "2",
        datetext: "06-03-2021",
        Occasiontext: "Filday",
        daytext: "Fri",
        iconimg: iconimg,
        deleteiconimg: deleteiconimg,
    },
]
export default CalendarFebuary_Array;