

//
import avatar_02img from "../../../../../assets/images/avatar_02.svg";
import avatar_01img from "../../../../../assets/images/avatar_01.svg";
import avatar_03img from "../../../../../assets/images/avatar_03.svg";

const MemberData_Array = [
    {
        key: "0",
        avatarimg: avatar_02img,
        title: "Jocelyn Bauch",
        email: "hugh77@example.net",
    },
    {
        key: "1",
        avatarimg: avatar_01img,
        title: "Jeanne Bailey",
        email: "nick26@example.com",
    },
    {
        key: "2",
        avatarimg: avatar_03img,
        title: "Julia Baqvi",
        email: "nick26@example.com",
    },
]
export default MemberData_Array;