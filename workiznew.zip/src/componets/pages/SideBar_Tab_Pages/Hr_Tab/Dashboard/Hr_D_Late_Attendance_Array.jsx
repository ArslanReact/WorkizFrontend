const Hr_D_Late_Attendance_Array = [
    {
        key: "0",
        text: "Admin",
        number_text: "16",
        circle_number: "lightparagraphcolorbg border-radius-50",
    },
    {
        key: "1",
        text: "Florian Torphy",
        number_text: "11",
        circle_number: "lightparagraphcolorbg border-radius-50",
    },
    {
        key: "2",
        text: "Laverna Upton",
        number_text: "8",
        circle_number: "lightparagraphcolorbg border-radius-50",
    },
    {
        key: "3",
        text: "Therese Bahringer",
        number_text: "6",
        circle_number: "lightparagraphcolorbg border-radius-50",
    },
    {
        key: "4",
        text: "Vivienne Kunde",
        number_text: "3",
        circle_number: "lightparagraphcolorbg border-radius-50",
    },
    {
        key: "5",
        text: "Robb Kassulke",
        number_text: "10",
        circle_number: "lightparagraphcolorbg border-radius-50",
    },
    {
        key: "6",
        text: "Maurice Goodwin",
        number_text: "12",
        circle_number: "lightparagraphcolorbg border-radius-50",
    },
]
export default Hr_D_Late_Attendance_Array;