const TexModalTableLoop_Array = [
    {
        key: "0",
        countnumber: "1",
        name: "zxcxzc",
        number: "2",
    },
]
export default TexModalTableLoop_Array;