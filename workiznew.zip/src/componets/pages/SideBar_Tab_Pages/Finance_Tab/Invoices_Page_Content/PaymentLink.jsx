import React from 'react';

const PaymentLink = () => {
    return (
        <>
            Payment Link
        </>
    )
}

export default PaymentLink;
