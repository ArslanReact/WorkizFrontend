import React from 'react';

const AddCreditNote = () => {
    return (
        <>
            Add Credit Note
        </>
    )
}

export default AddCreditNote;
