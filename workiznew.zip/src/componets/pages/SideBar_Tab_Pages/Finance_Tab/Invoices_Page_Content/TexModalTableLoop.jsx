import React from 'react';

const TexModalTableLoop = (props) => {
    return (
        <>
            <tr>
                <td>{props.countnumber}</td>
                <td>{props.name}</td>
                <td>{props.number}</td>
            </tr>
        </>
    )
}

export default TexModalTableLoop;
