const InvoiceTableLoop_Array = [
    {
        key: "0",
        countnumber: "1",
        itemsnumber: "Item 6",
        hsnsac_text: "--",
        qty_text: "1",
        unitprice: "$2033",
        price: "$2055",
    },
    {
        key: "1",
        countnumber: "2",
        itemsnumber: "Item 8",
        hsnsac_text: "--",
        qty_text: "2",
        unitprice: "$2066",
        price: "$2099",
    },
]
export default InvoiceTableLoop_Array;