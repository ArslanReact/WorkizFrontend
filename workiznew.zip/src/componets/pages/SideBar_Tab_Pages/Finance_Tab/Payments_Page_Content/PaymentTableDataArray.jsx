import editiconimg from "../../../../../assets/images/editiconimg.svg";
import viewiconimg from "../../../../../assets/images/viewiconimg.svg";
import deleteiconimg from "../../../../../assets/images/deleteiconimg.svg";
import iconimg from "../../../../../assets/images/dotoption.svg";


const PaymentTableData_Array = [
    {
        key: "0",
        count_number: "1",
        invoicenumber: "INV#040",
        projectname: "Web Design",
        amounttext: "$3994 (USD)",
        paidontext: "09-04-2021 12:00 AM",
        badgetext: "Completed",
        dashes: "--",
        iconimg: iconimg,
        editiconimg: editiconimg,
        viewiconimg: viewiconimg,
        deleteiconimg: deleteiconimg,
    },
    {
        key: "1",
        count_number: "1",
        invoicenumber: "INV#040",
        projectname: "Web Design",
        amounttext: "$3994 (USD)",
        paidontext: "09-04-2021 12:00 AM",
        badgetext: "Completed",
        dashes: "--",
        iconimg: iconimg,
        editiconimg: editiconimg,
        viewiconimg: viewiconimg,
        deleteiconimg: deleteiconimg,
    },
    {
        key: "2",
        count_number: "1",
        invoicenumber: "INV#040",
        projectname: "Web Design",
        amounttext: "$3994 (USD)",
        paidontext: "09-04-2021 12:00 AM",
        badgetext: "Completed",
        dashes: "--",
        iconimg: iconimg,
        editiconimg: editiconimg,
        viewiconimg: viewiconimg,
        deleteiconimg: deleteiconimg,
    },
]
export default PaymentTableData_Array;