import React from 'react'

const Dummy = () => {
    return (
        <>
            <h1>jingaa lalaaaa hu hu hu</h1>
        </>
    )
}
export default Dummy;